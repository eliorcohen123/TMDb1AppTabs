package eliorcohen.com.tmdbapptabs.DataAppPackage;

public class JSONResponse {

    private MovieModel[] results;

    public MovieModel[] getResults() {
        return results;
    }

}
